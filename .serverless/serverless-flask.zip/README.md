## Work on local

Execute below command

````
python -m flask run
````

And request [http://127.0.0.1:5000](http://127.0.0.1:5000/hoge)


## Deploy to Lambda

````
````
